package motor;

public enum State {
	Start, Run, Pause, GameOver, Victoire
}
