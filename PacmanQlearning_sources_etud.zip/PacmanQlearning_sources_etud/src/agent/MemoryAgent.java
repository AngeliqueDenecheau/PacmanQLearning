package agent;

import java.util.ArrayList;

import neuralNetwork.TrainExample;

public class MemoryAgent {


	public double[] currentStateAction;
	public ArrayList<TrainExample> trainExamples  = new ArrayList<TrainExample>();
	
	public double[] statePrediction;
	
}
