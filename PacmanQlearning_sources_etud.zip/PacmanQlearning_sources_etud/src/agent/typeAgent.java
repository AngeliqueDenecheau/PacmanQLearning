package agent;

public enum typeAgent {
	PACMAN, FANTOM
}
