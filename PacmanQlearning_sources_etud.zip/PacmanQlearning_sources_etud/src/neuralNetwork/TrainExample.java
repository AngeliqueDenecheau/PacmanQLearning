package neuralNetwork;

public class TrainExample {

	double[] X;
	double[] Y;
	
	public TrainExample(double[] X, double[] Y) {
		
		this.X = X;
		this.Y = Y;
		
	}

	public double[] getX() {
		return X;
	}

	public double[] getY() {
		return Y;
	}

	
	
}
